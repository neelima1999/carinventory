package com.car.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.car.model.CarPojo;

public class CarDao {

	private JdbcTemplate jdbcTemplate;

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void insertCar(CarPojo pojo) {
		jdbcTemplate.update(
				"insert into car(cid,make,model,year,salesprice) values('" + pojo.getCid() + "','" + pojo.getMake()
						+ "','" + pojo.getModel() + "','" + pojo.getYear() + "','" + pojo.getSalesprice() + "')");
	}

	public List getList() {
		String save = "select * from car";
		return jdbcTemplate.query(save, new RowMapper<CarPojo>() {
			public CarPojo mapRow(java.sql.ResultSet rs, int rowNum) throws SQLException {
				CarPojo cp = new CarPojo();
				cp.setCid(rs.getInt(1));
				cp.setMake(rs.getString(2));
				cp.setModel(rs.getString(3));
				cp.setYear(rs.getInt(4));
				cp.setSalesprice(rs.getInt(5));
				return cp;
			}
		});
	}

}