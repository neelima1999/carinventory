package com.car.main;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.car.dao.CarDao;
import com.car.model.CarPojo;

/**
 * Hello world!
 *
 */

public class App {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("bean.xml");
		CarDao cardao = (CarDao) ac.getBean("cardao");
		List<CarPojo> getList = cardao.getList();
		Scanner s = new Scanner(System.in);
		System.out.println("Welcome to Mullet Joe's Gently Used Autos!");
		System.out.println("Please enter command add , list or quit : ");
		String make, model;
		int cid, salesprice, year;
		String cmd = s.nextLine();
		if (cmd.equals("list")) {
			getList.forEach((z) -> System.out
					.println(z.getYear() + " " + z.getMake() + " " + z.getModel() + "  " + z.getSalesprice()));
		} else if(cmd.equals("add")) {
			System.out.println("Please enter car's cid : ");
			cid = s.nextInt();
			System.out.println("Please enter car's make : ");
			make = s.nextLine();
			System.out.println("Please enter car's model : ");
			model = s.nextLine();
			System.out.println("Please enter car's year: ");
			year = s.nextInt();
			System.out.println("Please enter car's price : ");
			salesprice = s.nextInt();
			CarPojo car = new CarPojo();
			car.setCid(cid);
			car.setMake(make);
			car.setModel(model);
			car.setYear(year);
			car.setSalesprice(salesprice);
			cardao.insertCar(car);
			System.out.println(car);

		}else {
			System.out.println("Good Bye");
		}
		
	}

}
